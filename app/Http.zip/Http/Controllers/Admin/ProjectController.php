<?php

namespace App\Http\Controllers\Admin;

use App\Models\Project;
use App\Models\Category; // Import the Category model
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ProjectController extends Controller
{
    /**
     * Show the form for creating a new project.
     */
    public function create()
    {
        $categories = Category::all(); // Fetch all categories
        return view('admin.projects.create', compact('categories'));
    }

    /**
     * Store a newly created project.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'video_url' => 'nullable|file|mimetypes:video/*',
            'abstract_url' => 'nullable|file|mimetypes:application/pdf',
            'category_id' => 'required|exists:categories,id', // Ensure category_id exists in the categories table
        ]);

        // Handle file uploads (video and abstract PDF)
        if ($request->hasFile('video_url')) {
            $validated['video_url'] = $request->file('video_url')->store('videos');
        }

        if ($request->hasFile('abstract_url')) {
            $validated['abstract_url'] = $request->file('abstract_url')->store('abstracts');
        }

        // Create the project
        $project = Project::create($validated);

        return redirect()->route('admin.projects.edit', $project)->with('success', 'Project created successfully.');
    }

    /**
     * Show the form for editing an existing project.
     */
    public function edit(Project $project)
    {
        $categories = Category::all(); // Fetch all categories
        return view('admin.projects.edit', compact('project', 'categories'));
    }

    /**
     * Update an existing project.
     */
    public function update(Request $request, Project $project)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'video_url' => 'nullable|file|mimetypes:video/*',
            'abstract_url' => 'nullable|file|mimetypes:application/pdf',
            'category_id' => 'required|exists:categories,id', // Ensure category_id exists in the categories table
        ]);

        // Handle file uploads (video and abstract PDF)
        if ($request->hasFile('video_url')) {
            $validated['video_url'] = $request->file('video_url')->store('videos');
        }

        if ($request->hasFile('abstract_url')) {
            $validated['abstract_url'] = $request->file('abstract_url')->store('abstracts');
        }

        // Update the project
        $project->update($validated);

        return redirect()->route('admin.projects.edit', $project)->with('success', 'Project updated successfully.');
    }

    /**
     * Delete an existing project.
     */
    public function destroy(Project $project)
    {
        $project->delete();

        return redirect()->route('admin.projects.index')->with('success', 'Project deleted successfully.');
    }
}