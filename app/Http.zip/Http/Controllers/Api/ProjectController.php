<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Project;
use Illuminate\Http\Request;

class ProjectController extends Controller
{
    public function index()
    {
        $projects = Project::where("status", "Published")->get();
        return response()->json($projects);
    }

    public function show($id)
    {
        $project = Project::findOrFail($id);
        return response()->json($project);
    }

    public function bookmark(Request $request, $id)
    {
        $user = $request->user();
        $project = Project::findOrFail($id);
        $user->bookmarks()->create(["project_id" => $project->id]);
        return response()->json(["message" => "Project bookmarked"]);
    }

    public function bookmarked(Request $request)
    {
        $user = $request->user();
        $bookmarks = $user->bookmarks()->with("project")->get();
        return response()->json($bookmarks);
    }
}
