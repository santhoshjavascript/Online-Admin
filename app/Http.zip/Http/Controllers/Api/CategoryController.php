<?php

namespace App\Http\Controllers;

use App\Models\Category;

class CategoryController extends Controller
{
    public function index()
    {
        // Fetch all categories
        $categories = Category::all();

        // Pass the $categories variable to the view
        return view('categories.index', compact('categories'));
    }
}