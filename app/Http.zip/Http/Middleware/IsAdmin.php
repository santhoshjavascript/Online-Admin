<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class IsAdmin
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        // Ensure the user is authenticated
        if (!Auth::check()) {
            abort(403, 'User is not authenticated.');
        }

        // Get the authenticated user
        $user = Auth::user();

        // Debugging: Log the authenticated user for debugging purposes
        \Log::info('Authenticated User:', ['id' => $user->id, 'name' => $user->name, 'role' => $user->role]);

        // Ensure the isAdmin() method exists on the User model
        if (!method_exists($user, 'isAdmin')) {
            abort(500, 'The isAdmin() method does not exist on the User model.');
        }

        // Ensure the user is an admin
        if (!$user->isAdmin()) {
            abort(403, 'Unauthorized action.');
        }

        // Proceed with the request
        return $next($request);
    }
}